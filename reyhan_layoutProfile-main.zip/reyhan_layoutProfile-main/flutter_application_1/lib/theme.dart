import 'package:flutter/material.dart';

final TitleTextStyle = TextStyle(
  fontSize: 40,
  fontWeight: FontWeight.w600,
);

final CaptionTextStyle = TextStyle(
  fontSize: 18,
  fontWeight: FontWeight.w500,
);