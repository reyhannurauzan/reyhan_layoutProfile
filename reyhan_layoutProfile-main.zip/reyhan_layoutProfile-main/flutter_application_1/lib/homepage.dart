import 'package:flutter/material.dart';
import 'widgets/info_card.dart';
import 'theme.dart';

const url = 'https://dribbble.com/reyhannurauzan';
const email = 'reyhan065118310@unpak.ac.id';
const phone = '085711033906';
const address = 'Tajurhalang - Bogor Barat';
const study = 'Universitas Pakuan';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              SizedBox(
                height: 40,
              ),
              Image.asset(
                'assets/RNA.jpg',
                height: 100,
                width: 100,
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                'Reyhan Nur Auzan',
                style: CaptionTextStyle,
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                '065118310',
                style: CaptionTextStyle.copyWith(
                  fontWeight: FontWeight.w400,
                  fontSize: 16,
                ),
              ),
              SizedBox(
                height: 20,
                width: 200,
                child: Divider(
                  color: Colors.black87,
                ),
              ),
              InfoCard(
                text: phone,
                icon: Icons.phone,
                onPressed: () async {},
              ),
              InfoCard(
                text: email,
                icon: Icons.email,
                onPressed: () async {},
              ),
              InfoCard(
                text: url,
                icon: Icons.web,
                onPressed: () async {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
